package Practice_Assissted;

import java.util.Arrays;
import java.util.Scanner;

public class BinarySearch {
public static void main(String[] args) {
	
	int a[]= {2,3,1,4,99,11,23,45,66,8};//unsorted 
	Arrays.sort(a);
	System.out.println("The sorted array is ");
	for(int b:a) {
		System.out.print(b+",");
	}
	System.out.println();
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the element to serach");
	int key=sc.nextInt();
	int low=0;
	int high=a.length-1;
	int mid=0;
	while(low<=high) {
		
		mid=(low+high)/2;
	
		if(a[mid]==key) {
			System.out.println("element is found at the location "+ (mid+1));
			break;
		}
		else if(a[mid]<key) {
			low=mid+1;
			
		}
		else {
			high=mid-1;
		}
		
	}
	
	
}
}
