package Practice_Assissted;
import java.util.Arrays;
import java.util.Scanner;

public class LinearSearch {
public static void main(String[] args) {
	
	int a[]= {2,3,1,4,99,11,23,45,66,8};//unsorted 
	Arrays.sort(a);
	for(int b:a) {
		System.out.print(b+",");
	}
	Scanner sc=new Scanner(System.in);
	System.out.println();
	System.out.println("enter the element to serach");
	int key=sc.nextInt();
	int flag=0;
	int i=0;
	for(i=0;i<a.length;i++) {
		if(a[i]==key) {
		flag=1;
		break;
		}
		else {
			flag=0;
		}
	}
	
	if(flag==1) {
		System.out.println("the element found at ith location "+i);
	}
	else {
		System.out.println("element is not found");
	}
}
}
