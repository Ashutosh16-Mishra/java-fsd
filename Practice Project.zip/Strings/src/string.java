public class string {
	public static void main(String[] args) {
		System.out.println("String methods");
		String st = new String("Hey There !!!");
		System.out.println(st.length());
		
		String subStr = new String("Congratulations!!!");
		System.out.println(subStr.substring(3));
		
		String s1 = "Hello";
		String s2 = "World";
		System.out.println(s1.compareTo(s2)); //comparison of two strings
		
		String s3 = "WELCOME";
		System.out.println(s3.toLowerCase()); // Lower case conversion
		
		String s4="Everyone";
		String replace=s4.replace('r', 'o');
		System.out.println(replace); // replace 
		
		System.out.println("\n");
		System.out.println("Creating a StringBuffer");
		StringBuffer s=new StringBuffer("Welcome to Java!!!");
		s.append("Enjoy your learning");
		System.out.println(s);
		
		s.insert(3, 'l');
		System.out.println(s);
		
		System.out.println("\n");
		System.out.println("Creating StringBuilder");
		StringBuilder sb1=new StringBuilder("Happy");
		sb1.append("Learning");
		System.out.println(sb1);
		System.out.println(sb1.delete(0, 1));
		System.out.println(sb1.insert(1, "Welcome"));
		System.out.println(sb1.reverse());
				
	
		System.out.println("\n");
		System.out.println("Conversion of Strings to StringBuffer and StringBuilder");
		String str = "Hello"; 
        
     
        StringBuffer sbr = new StringBuffer(str); 
        sbr.reverse(); 
        System.out.println("String to StringBuffer");
        System.out.println(sbr); 
           
        StringBuilder sbl = new StringBuilder(str); 
        sbl.append("world"); 
        System.out.println("String to StringBuilder");
        System.out.println(sbl);              		
		
	}
}
