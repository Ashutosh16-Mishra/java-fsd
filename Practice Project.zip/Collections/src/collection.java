import java.util.*;
public class collection {
	public static void main(String[] args) {
		System.out.println("Creating an Array List");
		ArrayList<String> list = new ArrayList<String>();
		list.add("Ashutosh");
		list.add("Sohail");
		list.add("Pratik");
		list.add("Akansha");
		System.out.println(list);
		
		System.out.println("\n");
		
		System.out.println("Creating an Linked List");
		LinkedList<String> link = new LinkedList<String>();
		link.add("Ashutosh");
		link.add("Sohail");
		link.add("Pratik");
		link.add("Akansha");
		Iterator<String> itr = link.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
			
		}
		System.out.println("\n");
		System.out.println("Creating a vector");
		Vector<Integer> v=new Vector<Integer>(); 
		v.add(10);
		v.add(30);
		v.add(50);
		v.add(70);
		v.add(90);
		System.out.println(v);
		
		System.out.println("\n");
		System.out.println("Creating a Hash Set");
		HashSet<String> set = new HashSet<String>();
		set.add("Saina");
		set.add("Simran");
		set.add("Ashutosh");
		set.add("Saina");
		System.out.println(set);
		
		System.out.println("\n");
		System.out.println("Creating a Linked Hash Set");
		LinkedHashSet<String> set2 = new LinkedHashSet<String>();
		set2.add("Rahul");
		set2.add("Rohan");
		set2.add("Vijay");
		set2.add("Rahul");
		System.out.println(set2);
	}
}
