public class array {
	public static void main(String[] args) {
		int a[] = {13,17,21,28,32};
		System.out.println("The elements of the array are : ");
		for(int i=0;i<5;i++) {
			System.out.println("Elements of array a are :" + a[i]);
		}
	}
}
