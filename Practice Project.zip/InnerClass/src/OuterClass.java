public class OuterClass {
	int num = 25;
	public void HeyThere() {
		System.out.println("Hey There!!!");
	}
	public class InnerClass{
		int innerNumber = 30;
		public void whatsUp() {
			System.out.println("What's Up from the inner class");
		}
	}
}
