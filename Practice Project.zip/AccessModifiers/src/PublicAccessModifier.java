
class PublicClass{
	public void display() {
		System.out.println("Welcome to JAVA IDE !!!");
	}
}
public class PublicAccessModifier {
	public static void main(String[] args) {
		System.out.println("Public Access Modifier");
		PublicClass Obj = new PublicClass();
		Obj.display();
	}
}
