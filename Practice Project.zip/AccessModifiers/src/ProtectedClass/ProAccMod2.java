package ProtectedClass;

public class ProAccMod2 {
	protected void display() {
		System.out.println("Protected Access Modifiers");
		System.out.println("Welcome to the IT World!!!");
	}
}
