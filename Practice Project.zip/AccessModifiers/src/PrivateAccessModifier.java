class PrivateClass{
	private void display() {
		System.out.println("Welcome!!!");
	}
}
public class PrivateAccessModifier {
	public static void main(String[] args) {
		System.out.println("Private Access Modifier");
		PrivateClass Obj = new PrivateClass();
		
	}
}
