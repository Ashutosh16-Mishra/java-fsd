class defaultClass{
	void display() {
		System.out.println("Welcome!!!");
	}
}

public class defAccModifier {
	public static void main(String[] args) {
		System.out.println("Default Access Modifiers");
		defaultClass Obj = new defaultClass();
		Obj.display();
	}
}
