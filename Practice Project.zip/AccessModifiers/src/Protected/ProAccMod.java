package Protected;
import ProtectedClass.ProAccMod2;
public class ProAccMod extends ProAccMod2{
	public static void main(String[] args) {
		ProAccMod Obj = new ProAccMod();
		Obj.display();
	}
}
