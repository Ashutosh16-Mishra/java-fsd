import java.util.*;
public class maps {

	public static void main(String[] args) {
		HashMap<Integer,String> hash=new HashMap<Integer,String>();      
	      hash.put(1,"Rahul");    
	      hash.put(2,"Ronak");    
	      hash.put(3,"Ravindra");   
	       
	      System.out.println("\nThe elements of Hashmap are ");  
	      for(Map.Entry m:hash.entrySet()){    
	       System.out.println(m.getKey()+" "+m.getValue());    
	      }
	      
	      System.out.println("\n");
	      Hashtable<Integer,String> hm=new Hashtable<Integer,String>();

	      hm.put(4,"Amit");
	      hm.put(5,"Ravi");
	      hm.put(6,"Vijay");
	      hm.put(7,"Rahul");
	      
	      System.out.println("\nThe elements of HashTable are "); 
	      for(Map.Entry m:hm.entrySet()){
	       System.out.println(m.getKey()+" "+m.getValue());
	      }
	      
	      System.out.println("\n");
	      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
	      map.put(8,"Annie");    
	      map.put(9,"Carlotte");    
	      map.put(10,"Catie");       
	      
	      System.out.println("\nThe elements of TreeMap are ");  
	      for(Map.Entry l:map.entrySet()){    
	       System.out.println(l.getKey()+" "+l.getValue());    
	      }    

	}
}