
public class TypeCasting {
	public static void main(String[] args) {
		System.out.println("Implicit Type Casting");
		byte a = 16;
		System.out.println("byte value is : " + a);
		short b = a;
		System.out.println("short value is : " + b);
		int c = b;
		System.out.println("int value is : " + c);
		long d = c;
		System.out.println("long value is : " + d);
		float e = d;
		System.out.println("float value is : " + e);
		double f = e;
		System.out.println("double value is : " + f);
		
		System.out.println("\n");
		
		System.out.println("Explicit Type Casting");
		double g= 16.7;
		byte h= (byte)g;
		int i =  (int)g;
		float j =(float)g;
		System.out.println("The value of g is : "+ g);
		System.out.println("The value of h is : "+ h);
		System.out.println("The value of i is : "+ i);
		System.out.println("The value of j is : "+ j);
	}
}
