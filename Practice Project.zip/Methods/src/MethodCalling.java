 public class MethodCalling {
	public int addNumbers(int a, int b) {
		int sum = a+b;
		return sum;
	}
	public static void main(String[] args) {
		int num1=20;
		int num2= 40;
		MethodCalling Obj = new MethodCalling();
		int result = Obj.addNumbers(num1, num2);
		System.out.println("Sum of two numbers is : "+ result);
	}
}
