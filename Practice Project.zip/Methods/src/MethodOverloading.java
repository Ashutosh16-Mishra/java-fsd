public class MethodOverloading {
	void sum(int a, int b) {
		System.out.println("Sum is : " + (a+b));
	}
	void sum(float a, float b) {
		System.out.println("Sum is : " + (a+b));
	}
	public static void main(String[] args) {
		MethodOverloading cal = new MethodOverloading();
		cal.sum(34,45);
		cal.sum(8.6f, 7.9f);
	}
}
