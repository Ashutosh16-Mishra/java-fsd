public class CallByValue {
	public static void increment(int value) {
		value++;
		System.out.println("Inside Method");
		System.out.println("value is = " + value);
	}
	public static void main(String[] args) {
		int num = 26;
		System.out.println("Before calling : " + num);
		increment(num);
		System.out.println("After calling : " + num);
	}
}
