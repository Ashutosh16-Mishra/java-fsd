class Rectangle{
	double length = 23.6;
	double breadth = 23.6;
	double calculateArea() {
		return length*breadth;
	}
}
public class Default {
	public static void main(String[] args) {
		double area;
		Rectangle myRec = new Rectangle();
		area = myRec.calculateArea();
		System.out.println("Area of the rectangle is : " + area);
	}
}
