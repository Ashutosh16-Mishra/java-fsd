class rectangle2{
	double length, breadth;
	rectangle2(){
		length = 20;
		breadth = 15;
	}
	rectangle2(double l, double b){
		length = l;
		breadth = b;
	}
	double calculateArea() {
		return length*breadth;
	}
}
public class Parameterized {
	public static void main(String[] args) {
		double area;
		rectangle2 myRec = new rectangle2(23,23);
		area = myRec.calculateArea();
		System.out.println("Area of the rectangle is : " + area);
	}
}
