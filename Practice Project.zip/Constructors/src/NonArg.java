class rectangle1{
	double length;
	double breadth;
	rectangle1(){
		length = 16.45;
		breadth = 23.564;
	}
	double calculateArea() {
		return length*breadth;
	}
}
public class NonArg {
	public static void main(String[] args) {
		double area;
		rectangle1 myRec = new rectangle1();
		area = myRec.calculateArea();
		System.out.println("Area of the rectangle is : " + area);
	}
}
