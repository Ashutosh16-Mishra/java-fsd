package PracticeAssisted;
import java.util.Scanner;
public class throwsKeyword {
	int num1, num2, result;
	Scanner sc = new Scanner(System.in);
	
	void division() throws ArithmeticException{
		System.out.println("Enter two numbers");
		num1 = sc.nextInt();
		num2 = sc.nextInt();
		result = num1/num2;
		System.out.println(num1 + "/" + num2 +"=" + result);
	}
	public static void main(String[] args) {
		try {
			new throwsKeyword().division();
		}
		catch(ArithmeticException ae) {
			System.out.println("problem info :" +ae.getMessage());
		}
		System.out.println("End of the program");
	}
}
