package PracticeAssisted;

public class sleep {
	public static void main(String[] args) {
		sleep sl = new sleep();
		System.out.println("Hello World");
		sleep.timea();
		System.out.println("Welcome");
		sleep.timeb();
	}
	public static void timea(){
		try {
			Thread.sleep(2500);
		}
		catch(Exception e) {
			
		}
	}
	public static void timeb() {
		try {
			Thread.sleep(500);
			
		}
		catch(Exception e) {
			
		}
	}
}
