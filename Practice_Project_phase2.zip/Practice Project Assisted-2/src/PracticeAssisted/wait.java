package PracticeAssisted;

public class wait {
	public static void main(String[] args) {
		System.out.println("Hey There !!!");
		synchronized(args) {
			System.out.println("Welcome");
			try {
				args.wait(2500);
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			System.out.println("To the IT industry!!!");
		}
	}
}
