package PracticeAssisted;
import java.util.Scanner;
public class finallyKeyword {
	public static void main(String[] args) {
		int num1, num2, result;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two numbers");
		num1 = sc.nextInt();
		num2 = sc.nextInt();
		try {
			if(num2==0)
				throw new ArithmeticException("Division by zero");
			result = num1/num2;
			System.out.println(num1+ "/" +num2 +"=" +result);
		}
		catch(ArithmeticException ae) {
			System.out.println("problem info :" + ae.getMessage());
		}
		finally {
			System.out.println("The final block executes always");
		}
		System.out.println("End of the program");
	}
}
