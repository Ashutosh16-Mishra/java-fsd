package PracticeAssisted;
class SampleThread implements Runnable{
	public void run() {
		System.out.println("Thread is running...");
		for(int i=1; i<=10;i++) {
			System.out.println("i = " + i);
		}
	}
}
public class RunnableThread {
	public static void main(String[] args) {
		SampleThread Obj = new SampleThread();
		Thread thread = new Thread(Obj);
		System.out.println("Thread is about to start...");
		thread.start();
		
	}	
}

