package PracticeAssisted3;
import java.util.Arrays;
public class arrayRotation {
	public static void rotate(int[] inputArray,int n) {
		System.out.println("Input array before rotation :");
		System.out.println(Arrays.toString(inputArray));
		int temp;
		for(int i=0;i<n;i++) {
			temp = inputArray[0];
			for(int j=0;j<inputArray.length-1;j++) {
				inputArray[j] = inputArray[j+1];
			}
			inputArray[inputArray.length-1]= temp;
		}
		System.out.println("Input Array after left rotation by " +" " +n + " "+"position is : ");
		System.out.println(Arrays.toString(inputArray));
	}
	public static void main(String[] args) {
		rotate(new int[] {1,2,3,4,5,6,7}, 4);
	}
}
